var NB_PAIRES = 10;
var CARTES = [];
var COMPTEUR = 0;
var RETOURNEES = [];
var TROUVEES = 0;


// CREATION DES CARTES

function definirSymboles(nb) {
    var res = [];
    for (var i = 0; i < nb; i++) {
        var temp = "";
        do {
            // symboles Dingbat UTF-8 : de &#9988; à &#10059;
            // Math.floor(Math.random() * (max - min) ) + min;
            temp = Math.floor(Math.random() * (10059 - 9988)) + 9988;
            temp = "&#" + temp + ";";
        }
        while (res.indexOf(temp) != -1)
        res[i] = temp;
    }
    return res;
}

function definirCouleurs(nb) {
    var res = [];
    var tab = "0123456789ABCD".split(""); // tableau des valeurs possibles
    for (var i = 0; i < nb; i++) {
        var temp = "#";
        do {
            for (var j = 0; j < 6; j++) {
                var indice = Math.floor(Math.random() * tab.length);
                temp += tab[indice];
            }
        }
        while (res.indexOf(temp) != -1)
        res[i] = temp;
    }
    return res;
}

function definirPositions(nb) {
    var res = [];
    var tab = [];
    // former le tableau d'indices
    for (var i = 0; i < nb; i++) {
        tab[i] = i;
    }
    // former un nouveau tableau en prenant les indices au hasard
    while (tab.length > 0) {
        var indice = Math.floor(Math.random() * tab.length);
        res.push(tab[indice]);
        tab.splice(indice, 1);
    }
    return res;
}

function Carte(numero_paire, symbole, couleur, position) {
    this.numero_paire = numero_paire;
    this.symbole = symbole;
    this.couleur = couleur;
    this.position = position;
}

function creerCartes(nb) {
    var res = [];
    var tabSymboles = definirSymboles(nb);
    var tabCouleurs = definirCouleurs(nb);
    var tabPositions = definirPositions(nb * 2); // pour les paires
    for (var i = 0; i < nb; i++) {
        var pos1 = tabPositions[i];
        var pos2 = tabPositions[i + nb];
        res[pos1] = new Carte(i, tabSymboles[i], tabCouleurs[i], pos1);
        res[pos2] = new Carte(i, tabSymboles[i], tabCouleurs[i], pos2);
    }
    return res;
}



// INITIALISATION DU JEU

function creerDivs(nb, id, str) {
    var tab = [];
    for (var i = 0; i < nb; i++) {
        tab.push('<div id="' + id + i + '" class="' + str + '">&nbsp;</div>');
    }
    return tab;
}

function initJeu() {
    COMPTEUR = 0;
    TROUVEES = 0;
    RETOURNEES = [];
    // créer les divs pour les cartes dans la page
    $('#cartes').html(creerDivs(NB_PAIRES * 2, "", "carte dos pointer"));
    $('#paires').html(creerDivs(NB_PAIRES, "paire", "carte vide"));
    // créer les cartes et les associer aux divs
    CARTES = creerCartes(NB_PAIRES);
    for (var i = 0; i < CARTES.length; i++) {
        $('#' + i).html(CARTES[i].symbole);
    }
    // afficher les instructions
    $('#message').html('Cliquez sur les cartes et trouvez les paires le plus rapidement possible.');
    // initialiser le click sur les cartes à retourner (mais pas sur les paires)
    $('#cartes > .carte').click(cliquerCarte);
    // cacher le bouton "nouveau jeu"
    $('#nouveau').css('display', 'none');
    return true;
}



// DEROULEMENT DU JEU

function cacherCarte(id) {
    $('#' + id).css('color', 'transparent');
    $('#' + id).addClass('dos');
    return true;
}

function viderCarte(id) {
    $('#' + id).css('color', 'transparent');
    $('#' + id).addClass('vide');
    $('#' + id).removeClass('pointer');
    $('#' + id).html('&nbsp;');
    return true;
}

function comparerCartes() {
    COMPTEUR++;
    if (CARTES[RETOURNEES[0]].numero_paire == CARTES[RETOURNEES[1]].numero_paire) {
        TROUVEES++;
        // afficher la paire trouvée
        $('#paire' + CARTES[RETOURNEES[0]].numero_paire).html(CARTES[RETOURNEES[0]].symbole);
        $('#paire' + CARTES[RETOURNEES[0]].numero_paire).css('color', CARTES[RETOURNEES[0]].couleur);
        $('#paire' + CARTES[RETOURNEES[0]].numero_paire).removeClass('vide');
        // vider les cartes retournées
        viderCarte(RETOURNEES[0]);
        viderCarte(RETOURNEES[1]);
        // afficher le message
        if (TROUVEES == NB_PAIRES) {
            $('#message').html('Bravo ! Vous avez gagné en ' + COMPTEUR + ' coups !');
            // montrer le bouton "nouveau jeu"
            $('#nouveau').css('display', 'inline');
        }
        else {
            $('#message').html('Vous avez trouvé une paire !');
        }
    }
    else {
        $('#message').html('Choisissez d\'autres cartes...');
    }
    return true;
}

function retournerCarte(id) {
    // découvrir la carte
    $('#' + id).css('color', CARTES[id].couleur);
    $('#' + id).removeClass('dos');
    // ajouter l'id aux cartes retournées
    RETOURNEES.push(id);
    // si 2 cartes sont retournées
    if (RETOURNEES.length == 2) {
        comparerCartes();
    }
    return true;
}


function cliquerCarte() {
    var id = $(this).attr('id');
    // si 2 cartes sont déjà retournées, les cacher et repartir à zéro
    if (RETOURNEES.length == 2) {
        cacherCarte(RETOURNEES[0]);
        cacherCarte(RETOURNEES[1]);
        RETOURNEES = [];
    }
    // si moins de 2 cartes sont déjà retournées
    if ((RETOURNEES.length < 2) && $(this).hasClass('dos')) {
        retournerCarte(id);
    }
}



// CHARGEMENT DE LA PAGE

function main() {
    // initialiser le clic "nouveau jeu""
    $('#nouveau').click(initJeu);
    // lancer le premier jeu
    initJeu();
}

main();