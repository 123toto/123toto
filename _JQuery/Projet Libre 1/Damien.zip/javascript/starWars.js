

//créer un caroussel
$(document).ready(function () {
  $('.bxslider').bxSlider({
    auto: true,
    autoControls: true
  });
});

//initialise la page en cachant les liste 
$('.episode1 ul').hide();
$('.episode2 ul').hide();
$('.episode3 ul').hide();
$('.episode4 ul').hide();
$('.episode5 ul').hide();
$('.episode6 ul').hide();
$('.episode7 ul').hide();



//fais apparaître puis cache la liste lorque le bouton est cliqué
$('#bouton1').click(function () {
  $('.episode1 ul').toggle();
});

$('#bouton2').click(function () {
  $('.episode2 ul').toggle();
});

$('#bouton3').click(function () {
  $('.episode3 ul').toggle();
});

$('#bouton4').click(function () {
  $('.episode4 ul').toggle();
});

$('#bouton5').click(function () {
  $('.episode5 ul').toggle();
});

$('#bouton6').click(function () {
  $('.episode6 ul').toggle();
});

$('#bouton7').click(function () {
  $('.episode7 ul').toggle();
});


