/*************************
 * Bandit Manchot Didier *
 * Simplon               *
 * Promo La Poste        *
 * 31-12-2016            *
 *************************/

// initialisation des variables globales
var ptf = 20, mise = 0, gain = 0;                           // variables du joueur
var myVar, myVar2;
var num1 = 0, num2 = 0, num3 = 0, duree = 100, i = 0;                    // variables du tirage
 
// lance le jeu avec une popup qui s'efface
function lancerJeu() {
    $("#generique").fadeOut(4000);                          // masque la popup de lancement du jeu
}

// initialise les 3 chiffres du jeu
function initialiser() {
    num1 = Math.floor(Math.random()*10);                    // tire un nombre au hasard entre 0 et 9
    num2 = Math.floor(Math.random()*10);                    // tire un nombre au hasard entre 0 et 9
    num3 = Math.floor(Math.random()*10);                    // tire un nombre au hasard entre 0 et 9
    duree = 100;                                            // initialise la durée à 100 ms
}

// afficher la mise
function miser(mise) {
    $("#votremise").text("$" + mise);                       // affiche la mise du joueur
}
 
// décoche toutes les mises
function decocherMise() {
    document.getElementById("10").checked = false;          // décoche la mise de 10$
    document.getElementById("5").checked = false;           // décoche la mise de 5$
    document.getElementById("2").checked = false;           // décoche la mise de 2$
    document.getElementById("1").checked = false;           // décoche la mise de 1$
}

// vérifie l'affichage des mises
function afficherMise() {
    decocherMise();                                         // décoche toutes les mises
    if (ptf < 10) {                                         // si PTF < 10 masque la mise 10$
        $("#10").hide();
    }
    else {
        $("#10").show();                                    // sinon affiche la mise 10$
    }
    if (ptf < 5) {                                          // si PTF < 5 masque la mise 5$
        $("#5").hide();
    }
    else {
        $("#5").show();                                     // sinon affiche la mise 5$
    }
    if (ptf < 2) {
        $("#2").hide();                                     // si PTF < 2 masque la mise 2$
    }
    else {
        $("#2").show();                                     // sinon affiche la mise 2$
    }
    if (ptf < 1) {                                          // si PTF < 1 masque la mise 1$
        $("#1").hide();
        gameOver();                                         // lance la fonction de fin de jeu
    }
    else {
        $("#1").show();                                     // sinon affiche la mise 1$
    }
}

// met à jour l'affichage des 3 chiffres du tirage
function afficherEcran() {
    if (num1 == 9) {                                        // si chiffre 1 est égal à 9 on passe à 0
        num1 = 0;
    }
    else {
        num1++;                                             // sinon on passe au suivant
    }
    if (num2 == 9) {                                        // si chiffre 2 est égal à 9 on passe à 0
        num2 = 0;
    }
    else {
        num2++;                                             // sinon on passe au suivant
    }
    if (num3 == 9) {                                        // si chiffre 3 est égal à 9 on passe à 0
        num3 = 0;
    }
    else {
        num3++;                                             // sinon on passe au suivant
    }
    i++;
    $("#c1").text(num1);                                    // affiche le chiffre 1
    $("#c2").text(num2);                                    // affiche le chiffre 2
    $("#c3").text(num3);                                    // affiche le chiffre 3
    if (i > 15) {
        clearInterval(myVar);                               // stoppe le tirage
        i = 0;                                              // réinitialise i à 0
        gagner();                                           // calcule les gains suite au tirage
        afficherMise();                                     // affiche le bouton pour miser
    }
}

// vérifie les gains suite au tirage
function gagner() {
    gain = 0;
    if (num1 == 4 && num2 == 2 && num3 == 1) {                                  // si 421 gain = 100 x la mise
        gain = mise * 100;
    }
    else if (num1 == 9 && num2 == 9 && num3 == 9) {                             // si 999 gain = 5 x la mise
            gain = mise * 5;
            }
            else if (num1 == num2 && num1 == num3) {                            // si 3 chiffres identiques gain = 3 x la mise
                    gain = mise * 3;
                    }
                    else if (num1 == num2 || num1 == num3 || num2 == num3) {    // si 2 chiffres identiques gain = 2 x la mise
                            gain = mise * 2;
                            }
                            else if (num1 == 9 || num2 == 9 || num3 == 9) {     // si un 9 gain = 1 x la mise
                                gain = mise * 1;
                                }
    ptf = ptf + gain - mise;
    $("#votreMise").text("Votre mise = $" + mise);                              // affiche la mise
    $("#votrePtf").text("Votre PTF = $" + ptf);                                 // affiche le montant du PTF
    $("#votreGain").text("Votre gain = $" + gain);                              // affiche le gain
    mise = 0                                                                    // remet la mise à 0
    afficherBouton(mise);                                                       // affiche le bouton pour miser
}

// affiche une popup pour la fin du jeu
function gameOver() {
    $("#GameOver").fadeIn(4000)                                 // affiche la popup de fin de jeu
}

function jouer() {
    if (mise > 0) {
        initialiser();                                          // initialise les 3 chiffres du tirage
        myVar = setInterval(afficherEcran, duree);              // lance le tirage
    }
    afficherBouton(mise);                                       // affiche le bouton pour miser
}

// affiche le bouton qui convient entre Miser et Jouer
function afficherBouton(mise) {
    if (mise == 0) {                                            // si mise est nulle
        $("#play").removeClass("btn-success");                  // supprime la classe btn-success
        $("#play").addClass("btn-warning");                     // ajoute la classe btn-warning
        $("#play").text("MISER");                               // affiche le texte Miser
    }
    else {                                                      // sinon
        $("#play").removeClass("btn-warning");                  // supprime la classe btn-warning
        $("#play").addClass("btn-success");                     // ajoute la classe btn-success
        $("#play").text("JOUER");                               // affiche le texte Jouer
    }
}

// les commandes du jeu
$(document).ready(function(){
    $("#GameOver").hide();                                      // masque la popup Game Over
    lancerJeu();                                                // affiche la popup de départ
    afficherBouton(mise);                                       // affiche le bouton pour miser
    $("#votrePtf").text("Votre PTF = $" + ptf);                 // affiche le montant du PTF du joueur

    $('input:radio[name=mise]').change(function() {             // si le joueur mise
        mise = this.value;                                      // enregistre le montant de la mise
        miser(mise);                                            // affiche la mise du joueur
        afficherBouton(mise);                                   // affiche le bouton pour jouer
    });
    $("#play").click(jouer);                                    // le joueur joue
});

