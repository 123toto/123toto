//VARIABLES GLOBALES
var STATE = "stop";
var INTERVAL;


//CHOISIR LA DUREE DU TIMER
function duration(choix){
	var choix = document.getElementById("minuteur").value;
	temps = choix*60;
	temps_restant = temps;
	print(temps_restant);
}	
//AFFICHAGE DU TEMPS EN MINUTES ET SECONDES
function print(t){
	var min = Math.floor(t/60);
	var sec = t%60;
		if (min < 10) {
    min = "0" + min;
  		}
  		if (sec < 10) {
    sec = "0" + sec;
		}
	$('.time').text(min+":"+sec);
}

//ACTIONS SUR LES BOUTONS
function play(){
	if(STATE != "play"){
		STATE = "play";
		INTERVAL = window.setInterval(function () {
      	temps_restant--;
      	print(temps_restant);
//raye les éléments de la liste à la fin du temps
      	if(temps_restant < 1){stop()};
  		}, 1000);
  	}
}
function pause(){
	STATE = "pause";
	window.clearInterval(INTERVAL);
}
function stop(){
	 STATE = "stop";
  	window.clearInterval(INTERVAL);
  	temps_restant = temps;
	print(temps_restant);
	rayer();
}

//PASSAGE DE 'EN COURS' A 'TERMINEE'
function rayer(){
	$('li').removeClass("loading").css({'text-decoration':'line-through',
	'background':'rgba( 255, 255, 255, .45 )'});
}


$(function(){

	$("#play").click(play);
  	$("#pause").click(pause);
	$("#stop").click(stop);

});

//CREATION DES ELEMENTS A AJOUTER A LA LISTE
function newElement() {	
  var li = document.createElement("li");
  li.className = "list-group-item loading";
  var inputValue = document.getElementById("task").value;
  var t = document.createTextNode(inputValue);
  li.appendChild(t);
  if (inputValue === '') {
  	alert("veuillez remplir le champ 'A Faire'");
  } 
  else {
//ajout au début de la liste
    document.getElementById("done").prepend(li); 
  }
//vidage du champ 'à faire'
  document.getElementById("task").value = "";
//suppression du dernier élément si liste > 3 éléments
var nbrEl = $('li').length;
	if(nbrEl>3){
  $('#done').children().last().remove();  
  	}
  	
}

