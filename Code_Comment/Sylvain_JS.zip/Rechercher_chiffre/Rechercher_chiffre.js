function trouverChiffre() {
	var vies = 10; //initialise les nombre de vies à 10.
	var chiffreADeviner = Math.round( Math.random() * 100 ); //Variable qui accueille un nombre entre 0 et 100.
	var chiffreRenvoye = prompt( "Entrer un nombre entre 0 et 100." ); //Affiche le prompt de saisie d'un nombre.

	while ( chiffreRenvoye !== chiffreADeviner && vies !== 1 ) {
		vies -= 1; //De toutes façons, quoiqu'il arrive, tu perds un essai (une vie).
		if ( chiffreRenvoye < chiffreADeviner ) { //Si le chiffre renvoyé est plus petit que le chiffre à deviner…
			chiffreRenvoye = prompt( "Vous avez rentré : " + chiffreRenvoye + "   Entrez une valeur plus grande. Et il vous reste " + vies + " essai(s)." ); //Le prompt demande une valeur plus grande.
		} else if ( chiffreRenvoye > chiffreADeviner ) { //Si le chiffre renvoyé est plus grand que le chiffre à deviner…
			chiffreRenvoye = prompt( "Vous avez rentré : " + chiffreRenvoye + "   Entrez une valeur plus petite. Et il vous reste " + vies + " essai(s)." ); //Le prompt demande une valeur plus petite.
		} else if ( isNaN( chiffreRenvoye ) ) { //Si la valeur rentrée n'est pas un nombre…
			chiffreRenvoye = prompt( "Vous avez rentré : " + chiffreRenvoye + "   Entrez un NOMBRE entre 0 et 100. Et il vous reste " + vies + " essai(s), du coup…" ); //Le prompt demande de rentrer une valeur correcte.
		} else {
			break; //Coupe la boucle while en cas de bonne réponse (c-a-d, si aucune des conditions précédente n'est vérifiée).
		}
	}
	if ( chiffreRenvoye == chiffreADeviner ) { //Si le nombre renvoyé est le même que le nombre à deviner…
		alert( "Vous avez gagné !  " + "  Le chiffre à trouver était effectivement :   " + chiffreADeviner + "   Tout ça en  " + ( 10 - vies ) + "   essai(s) !!!" ); //Une alerte signifiant la victoire s'affiche ainsi que le nombre de coups nécessaires pour y parvenir.
	}
	if ( vies === 1 ) { //Si toutes les vies sont épuisées…
		alert( "Perdu, bouffon…" ); //Alerte signifiant la défaite.
	}
}

function main() { //Appelle la fonction trouverChiffre, celle au-desus.
	trouverChiffre();
}
main(); //Go!
