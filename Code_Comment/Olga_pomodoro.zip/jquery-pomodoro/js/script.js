var TIMER = 0;
var ETAT = "stop";
var INTERVAL = 0;
var NB_TACHE = 0;

function appuyerEntree() {
    if (event.keyCode == 13) {
        // annuler le rechargement de la page au submit du formulaire
        event.preventDefault();
        // même effet que le bouton play
        play();
    }
    return true;
}

function ecrire(temps) { // retourne le temps écrit proprement en minutes : secondes
    var minutes = Math.floor(temps / 60);
    var secondes = temps % 60;
    if (minutes < 10) {
        minutes = "0" + minutes;
    }
    if (secondes < 10) {
        secondes = "0" + secondes;
    }
    return minutes + ":" + secondes;
}

function play() {
    // ne rien faire si la fonction play() est déjà en cours d'exécution
    if (ETAT != "play") {
        // forcer l'utilisateur à entrer le nom de sa tâche
        if ($('#task').val() == '') {
            alert('Veuillez décrire la tâche à effectuer');
        } 
        else {
            // interdire la modification de la tâche
            $('#task').attr('disabled', 'disabled');
            // (re)lancer le timer et l'afficher jusqu'à ce qu'il tombe à zéro
            ETAT = "play";
            INTERVAL = window.setInterval(function () {
                if (TIMER > 0) {
                    TIMER--;
                    $('.time').text(ecrire(TIMER));
                } 
                else {
                    finirTache();
                }
            }, 1000);
        }
    }
    return true;
}

function pause() { // met le timer en pause
    ETAT = "pause";
    window.clearInterval(INTERVAL);
    return true;
}

function commencerPause(min) {
    var chrono = min * 60; // en secondes
    // interdire la saisie d'une nouvelle tâche et désactiver les boutons
    $('#task').val('Attendez la fin de la pause (' + min + ' minutes)');
    $('Button').attr('disabled', 'disabled');
    // lancer le chrono et l'afficher jusqu'à ce qu'il tombe à zéro
    INTERVAL = window.setInterval(function () {
        if (chrono > 0) {
            chrono--;
            $('.time').text(ecrire(chrono));
        } 
        else {
            finirPause();
        }
    }, 1000);
    return true;
}

function finirPause() {
    // arrêter le chrono
    window.clearInterval(INTERVAL);
    // initialiser la saisie d'une nouvelle tâche
    initialiserTache();
    return true;
}

function initialiserTache() {
    // initialiser le timer (25 minutes, en secondes)
    TIMER = 25 * 60;
    $('.time').text(ecrire(TIMER));
    // activer les boutons
    $('Button').removeAttr('disabled');
    // permettre la saisie d'une nouvelle tâche
    $('#task').removeAttr('disabled');
    $('#task').val('');
    $('#task').attr('placeholder', 'Votre tâche ici...');
    $('#task').focus();
    return true;
}

function finirTache() {
    var tempsPause = 0;
    // récupérer la tâche
    var tache = $('#task').val();
    // arrêter le timer et augmenter le compteur des tâches réalisées
    ETAT = "stop";
    window.clearInterval(INTERVAL);
    NB_TACHE++;
    // ajouter la tâche finie en début de liste et supprimer les trop vieilles
    $('.list-group').prepend('<li class="list-group-item">' + NB_TACHE + '. <s>' + tache + '</s></li>');
    if ($('li').length > 30) {
        $('li:last-child').remove();
    }
    // prendre 5 minutes de pause (ou 15 minutes toutes les 4 tâches)
    if (NB_TACHE % 4 != 0) {
        tempsPause = 5;
    } 
    else {
        tempsPause = 15;
    }
    commencerPause(tempsPause);
    return true;
}

$(document).ready(function () {
    // initialiser les événements touche entrée / clic boutons
    $('#task').keypress(appuyerEntree);
    $('#play').click(play);
    $('#pause').click(pause);
    $('#stop').click(finirTache);
    // initialiser la saisie d'une tâche
    initialiserTache();
    return true;
});